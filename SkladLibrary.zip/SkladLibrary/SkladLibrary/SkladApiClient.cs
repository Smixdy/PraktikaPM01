﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace SkladLibrary
{
    public class SkladApiClient
    {
        private readonly string _baseUrl;
        private readonly HttpClient _client = new HttpClient();

        public SkladApiClient(string baseUrl)
        {
            _baseUrl = baseUrl;
        }

        // 1. Получение списка складов
        public async Task<List<Склады>> GetSkladyAsync()
        {
            string url = $"{_baseUrl}/api/Склады";
            return await GetAsync<List<Склады>>(url);
        }

        // 2. Получение списка товаров
        public async Task<List<Товары>> GetТоварыAsync()
        {
            string url = $"{_baseUrl}/api/Товары";
            return await GetAsync<List<Товары>>(url);
        }

        // 3. Получение остатков товаров
        public async Task<List<ОстаткиТоваров>> GetОстаткиТоваровAsync()
        {
            string url = $"{_baseUrl}/api/ОстаткиТоваров";
            return await GetAsync<List<ОстаткиТоваров>>(url);
        }

        // 4. Получение категорий
        public async Task<List<Категории>> GetКатегорииAsync()
        {
            string url = $"{_baseUrl}/api/Категории";
            return await GetAsync<List<Категории>>(url);
        }

        // Универсальный метод для выполнения GET запросов и десериализации JSON
        private async Task<T> GetAsync<T>(string url)
        {
            try
            {
                HttpResponseMessage response = await _client.GetAsync(url);

                if (response.IsSuccessStatusCode)
                {
                    string json = await response.Content.ReadAsStringAsync();
                    T data = JsonConvert.DeserializeObject<T>(json);
                    return data;
                }
                else
                {
                    Console.WriteLine($"Ошибка при выполнении запроса к {url}: {response.StatusCode}");
                    return default(T); // Возвращаем значение по умолчанию для типа T (например, null для классов)
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Исключение при выполнении запроса к {url}: {ex.Message}");
                return default(T);
            }
        }
    }
}