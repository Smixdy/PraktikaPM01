﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace SkladLibrary
{
    // Пример класса Склады (ОБЯЗАТЕЛЬНО убедитесь, что имена свойств соответствуют API)
    public class Склады
    {
        public int склад_id { get; set; }
        public string название { get; set; }
        public string адрес { get; set; }
        public string тип { get; set; }
        public decimal широта { get; set; }
        public decimal долгота { get; set; }
    }

    public class Товары
    {
        public int товар_id { get; set; }
        public string название { get; set; }
        public string артикул { get; set; }
        public string штрихкод { get; set; }
        public int категория_id { get; set; }
        public string единица_измерения { get; set; }
        public decimal цена { get; set; }
        public bool учет_серийных_номеров { get; set; }
        public bool учет_сроков_годности { get; set; }
        public int минимальный_остаток { get; set; }
    }

    public class ОстаткиТоваров
    {
        public int товар_id { get; set; }
        public int склад_id { get; set; }
        public int количество { get; set; }
    }

    public class Категории
    {
        public int категория_id { get; set; }
        public string название { get; set; }
        public string описание { get; set; }
    }
    public class Пользователи
    {
        public int пользователь_id { get; set; }
        public string имя_пользователя { get; set; }
        public string хэш_пароля { get; set; }
        public string имя { get; set; }
        public string фамилия { get; set; }
        public string email { get; set; }
        public int роль_id { get; set; }
        public bool двухфакторная_аутентификация { get; set; }
    }
    public class Роли
    {
        public int роль_id { get; set; }
        public string название { get; set; }
        public string описание { get; set; }
    }
}