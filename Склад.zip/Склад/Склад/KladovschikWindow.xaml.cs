﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Data.Entity;
using System.Windows.Data; //  ОБЯЗАТЕЛЬНО добавьте using statement

namespace Склад
{
    public partial class KladovschikWindow : Window
    {
        public KladovschikWindow()
        {
            InitializeComponent();
            LoadSklady(); // Загружаем склады при открытии окна
        }

        // Загрузка списка складов
        private void LoadSklady()
        {
            try
            {
                using (var db = new СкладскойУчетEntities())
                {
                    // Загружаем склады из базы данных
                    var sklady = db.Склады.ToList();
                    cmbSklady.ItemsSource = sklady;
                    cmbSklady.DisplayMemberPath = "название"; // Отображаем название склада в ComboBox
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки складов: {ex.Message}");
            }
        }

        // Обработчик выбора склада
        private void cmbSklady_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //При изменении выбора в combobox вызывается этот метод
            if (cmbSklady.SelectedItem is Склады selectedSklad)
            {
                LoadTovaryNaSklade(selectedSklad.склад_id);
            }
        }

        // Загрузка товаров на выбранном складе
   
        public void LoadTovaryNaSklade(int skladId)
        {
            try
            {
                using (var db = new СкладскойУчетEntities())
                {
                    // Загружаем товары для выбранного склада, используя LINQ
                    var tovaryNaSklade = (from остатки in db.ОстаткиТоваров
                                          join товар in db.Товары on остатки.товар_id equals товар.товар_id
                                          where остатки.склад_id == skladId
                                          select new
                                          {
                                              Название = товар.название,
                                              Артикул = товар.артикул,
                                              Количество = остатки.количество
                                          }).ToList();

                    // Создаем CollectionViewSource
                    CollectionViewSource viewSource = new CollectionViewSource();
                    viewSource.Source = tovaryNaSklade;

                    // Устанавливаем DataContext для DataGrid
                    dgTovaryNaSklade.DataContext = viewSource;
                    dgTovaryNaSklade.SetBinding(ItemsControl.ItemsSourceProperty, new Binding());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки товаров: {ex.Message}");
            }
        }

        private void btnDodatTovar_Click(object sender, RoutedEventArgs e)
        {
            if (cmbSklady.SelectedItem is Склады selectedSklad)
            {
                DodatTovarWindow dodatTovarWindow = new DodatTovarWindow(this, selectedSklad);
                dodatTovarWindow.ShowDialog(); // Открываем окно как диалоговое
            }
            else
            {
                MessageBox.Show("Выберите склад!");
            }
        }
    }
}