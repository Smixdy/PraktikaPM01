﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Input;

namespace Склад  // Укажите правильное пространство имен
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MoveForm(object sender, MouseButtonEventArgs e)
        {
            this.DragMove();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var db = new СкладскойУчетEntities()) // Замените SkladEntities на имя вашего DbContext
                {
                    Пользователи user = null; // Инициализируем переменную user

                    if (rbLoginPassword.IsChecked == true)
                    {
                        // Авторизация по логину/паролю
                        user = db.Пользователи.FirstOrDefault(u => u.имя_пользователя == txtUsername.Text && u.хэш_пароля == PasswordBox.Password);
                    }
                    else if (rbEmailPassword.IsChecked == true)
                    {
                        // Авторизация по email/паролю
                        user = db.Пользователи.FirstOrDefault(u => u.email == txtUsername.Text && u.хэш_пароля == PasswordBox.Password);
                    }

                    if (user != null)
                    {
                        // Авторизация успешна
                        switch (user.роль_id) // Используем роль_id вместо type
                        {
                            case 2: // Кладовщик
                                KladovschikWindow kladovschikWindow = new KladovschikWindow();
                                kladovschikWindow.NameUsers.Content = user.имя; // Передаем имя пользователя
                                kladovschikWindow.Show();
                                this.Close();
                                break;

                            default:
                                MessageBox.Show("Авторизован (но нет обработки для этой роли)");
                                break;
                        }
                    }
                    else
                    {
                        // Авторизация не удалась
                        MessageBox.Show("Логин или пароль не верен");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения к БД: {ex.Message}");
            }
        }
    }
}