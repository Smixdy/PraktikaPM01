﻿using System;
using System.Linq;
using System.Windows;

namespace Склад
{
    public partial class DodatTovarWindow : Window
    {
        private KladovschikWindow _kladovschikWindow; // Ссылка на окно кладовщика
        private Склады _selectedSklad; // Выбранный склад

        public DodatTovarWindow(KladovschikWindow kladovschikWindow, Склады selectedSklad)
        {
            InitializeComponent();
            _kladovschikWindow = kladovschikWindow;
            _selectedSklad = selectedSklad;
            LoadKategorii(); // Загружаем категории при открытии окна
        }

        private void LoadKategorii()
        {
            try
            {
                using (var db = new СкладскойУчетEntities())
                {
                    var kategorii = db.Категории.ToList();
                    cmbKategoriya.ItemsSource = kategorii;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки категорий: {ex.Message}");
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var db = new СкладскойУчетEntities())
                {
                    // 1. Получаем данные из полей ввода
                    string nazvanie = txtNazvanieTovara.Text;
                    string artikul = txtArtikulTovara.Text;
                    if (!decimal.TryParse(txtCena.Text, out decimal cena))
                    {
                        MessageBox.Show("Неверный формат цены.");
                        return;
                    }
                    if (!int.TryParse(txtKolichestvo.Text, out int kolichestvo))
                    {
                        MessageBox.Show("Неверный формат количества.");
                        return;
                    }
                    string edinicaIzmereniya = txtEdinicaIzmereniya.Text;
                    Категории selectedKategoriya = cmbKategoriya.SelectedItem as Категории;

                    // 2. Проверка данных (добавьте необходимые проверки)
                    if (string.IsNullOrEmpty(nazvanie) || string.IsNullOrEmpty(artikul) || selectedKategoriya == null)
                    {
                        MessageBox.Show("Заполните все обязательные поля!");
                        return;
                    }

                    // 3. Создаем новый объект Товар (если такого товара еще нет)
                    Товары newTovar = db.Товары.FirstOrDefault(t => t.артикул == artikul);
                    if (newTovar == null)
                    {
                        newTovar = new Товары
                        {
                            название = nazvanie,
                            артикул = artikul,
                            категория_id = selectedKategoriya.категория_id,
                            единица_измерения = edinicaIzmereniya,
                            цена = cena
                        };
                        db.Товары.Add(newTovar);
                        db.SaveChanges(); // Сохраняем новый товар, чтобы получить его ID
                    }

                    // 4. Создаем новый объект ОстаткиТоваров
                    ОстаткиТоваров ostatki = new ОстаткиТоваров
                    {
                        товар_id = newTovar.товар_id,
                        склад_id = _selectedSklad.склад_id,
                        количество = kolichestvo
                    };

                    // 5. Добавляем остатки товара на склад
                    db.ОстаткиТоваров.Add(ostatki);

                    // 6. Сохраняем изменения в базе данных
                    db.SaveChanges();

                    // 7. Обновляем DataGrid в KladovschikWindow
                    _kladovschikWindow.LoadTovaryNaSklade(_selectedSklad.склад_id);

                    // 8. Закрываем окно
                    this.Close();

                    MessageBox.Show("Товар успешно добавлен!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка добавления товара: {ex.Message}");
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}