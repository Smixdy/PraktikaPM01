﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApplication.Entities;

namespace WebApplication.Controllers
{
    public class КатегорииController : ApiController
    {
        private СкладскойУчетEntities db = new СкладскойУчетEntities();

        // GET: api/Категории
        public IQueryable<Категории> GetКатегории()
        {
            return db.Категории;
        }

        // GET: api/Категории/5
        [ResponseType(typeof(Категории))]
        public IHttpActionResult GetКатегории(int id)
        {
            Категории категории = db.Категории.Find(id);
            if (категории == null)
            {
                return NotFound();
            }

            return Ok(категории);
        }

        // PUT: api/Категории/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutКатегории(int id, Категории категории)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != категории.категория_id)
            {
                return BadRequest();
            }

            db.Entry(категории).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!КатегорииExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Категории
        [ResponseType(typeof(Категории))]
        public IHttpActionResult PostКатегории(Категории категории)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Категории.Add(категории);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = категории.категория_id }, категории);
        }

        // DELETE: api/Категории/5
        [ResponseType(typeof(Категории))]
        public IHttpActionResult DeleteКатегории(int id)
        {
            Категории категории = db.Категории.Find(id);
            if (категории == null)
            {
                return NotFound();
            }

            db.Категории.Remove(категории);
            db.SaveChanges();

            return Ok(категории);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool КатегорииExists(int id)
        {
            return db.Категории.Count(e => e.категория_id == id) > 0;
        }
    }
}