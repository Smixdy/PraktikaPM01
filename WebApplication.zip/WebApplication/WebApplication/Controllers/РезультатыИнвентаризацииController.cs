﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApplication.Entities;

namespace WebApplication.Controllers
{
    public class РезультатыИнвентаризацииController : ApiController
    {
        private СкладскойУчетEntities db = new СкладскойУчетEntities();

        // GET: api/РезультатыИнвентаризации
        public IQueryable<РезультатыИнвентаризации> GetРезультатыИнвентаризации()
        {
            return db.РезультатыИнвентаризации;
        }

        // GET: api/РезультатыИнвентаризации/5
        [ResponseType(typeof(РезультатыИнвентаризации))]
        public IHttpActionResult GetРезультатыИнвентаризации(int id)
        {
            РезультатыИнвентаризации результатыИнвентаризации = db.РезультатыИнвентаризации.Find(id);
            if (результатыИнвентаризации == null)
            {
                return NotFound();
            }

            return Ok(результатыИнвентаризации);
        }

        // PUT: api/РезультатыИнвентаризации/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutРезультатыИнвентаризации(int id, РезультатыИнвентаризации результатыИнвентаризации)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != результатыИнвентаризации.инвентаризация_id)
            {
                return BadRequest();
            }

            db.Entry(результатыИнвентаризации).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!РезультатыИнвентаризацииExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/РезультатыИнвентаризации
        [ResponseType(typeof(РезультатыИнвентаризации))]
        public IHttpActionResult PostРезультатыИнвентаризации(РезультатыИнвентаризации результатыИнвентаризации)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.РезультатыИнвентаризации.Add(результатыИнвентаризации);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (РезультатыИнвентаризацииExists(результатыИнвентаризации.инвентаризация_id))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = результатыИнвентаризации.инвентаризация_id }, результатыИнвентаризации);
        }

        // DELETE: api/РезультатыИнвентаризации/5
        [ResponseType(typeof(РезультатыИнвентаризации))]
        public IHttpActionResult DeleteРезультатыИнвентаризации(int id)
        {
            РезультатыИнвентаризации результатыИнвентаризации = db.РезультатыИнвентаризации.Find(id);
            if (результатыИнвентаризации == null)
            {
                return NotFound();
            }

            db.РезультатыИнвентаризации.Remove(результатыИнвентаризации);
            db.SaveChanges();

            return Ok(результатыИнвентаризации);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool РезультатыИнвентаризацииExists(int id)
        {
            return db.РезультатыИнвентаризации.Count(e => e.инвентаризация_id == id) > 0;
        }
    }
}