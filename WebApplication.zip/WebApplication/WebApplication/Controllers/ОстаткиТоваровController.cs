﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApplication.Entities;

namespace WebApplication.Controllers
{
    public class ОстаткиТоваровController : ApiController
    {
        private СкладскойУчетEntities db = new СкладскойУчетEntities();

        // GET: api/ОстаткиТоваров
        public IQueryable<ОстаткиТоваров> GetОстаткиТоваров()
        {
            return db.ОстаткиТоваров;
        }

        // GET: api/ОстаткиТоваров/5
        [ResponseType(typeof(ОстаткиТоваров))]
        public IHttpActionResult GetОстаткиТоваров(int id)
        {
            ОстаткиТоваров остаткиТоваров = db.ОстаткиТоваров.Find(id);
            if (остаткиТоваров == null)
            {
                return NotFound();
            }

            return Ok(остаткиТоваров);
        }

        // PUT: api/ОстаткиТоваров/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutОстаткиТоваров(int id, ОстаткиТоваров остаткиТоваров)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != остаткиТоваров.товар_id)
            {
                return BadRequest();
            }

            db.Entry(остаткиТоваров).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ОстаткиТоваровExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/ОстаткиТоваров
        [ResponseType(typeof(ОстаткиТоваров))]
        public IHttpActionResult PostОстаткиТоваров(ОстаткиТоваров остаткиТоваров)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.ОстаткиТоваров.Add(остаткиТоваров);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (ОстаткиТоваровExists(остаткиТоваров.товар_id))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = остаткиТоваров.товар_id }, остаткиТоваров);
        }

        // DELETE: api/ОстаткиТоваров/5
        [ResponseType(typeof(ОстаткиТоваров))]
        public IHttpActionResult DeleteОстаткиТоваров(int id)
        {
            ОстаткиТоваров остаткиТоваров = db.ОстаткиТоваров.Find(id);
            if (остаткиТоваров == null)
            {
                return NotFound();
            }

            db.ОстаткиТоваров.Remove(остаткиТоваров);
            db.SaveChanges();

            return Ok(остаткиТоваров);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ОстаткиТоваровExists(int id)
        {
            return db.ОстаткиТоваров.Count(e => e.товар_id == id) > 0;
        }
    }
}