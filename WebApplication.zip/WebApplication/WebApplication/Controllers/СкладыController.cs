﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApplication.Entities;

namespace WebApplication.Controllers
{
    public class СкладыController : ApiController
    {
        private СкладскойУчетEntities db = new СкладскойУчетEntities();

        // GET: api/Склады
        public IQueryable<Склады> GetСклады()
        {
            return db.Склады;
        }

        // GET: api/Склады/5
        [ResponseType(typeof(Склады))]
        public IHttpActionResult GetСклады(int id)
        {
            Склады склады = db.Склады.Find(id);
            if (склады == null)
            {
                return NotFound();
            }

            return Ok(склады);
        }

        // PUT: api/Склады/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutСклады(int id, Склады склады)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != склады.склад_id)
            {
                return BadRequest();
            }

            db.Entry(склады).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!СкладыExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Склады
        [ResponseType(typeof(Склады))]
        public IHttpActionResult PostСклады(Склады склады)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Склады.Add(склады);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = склады.склад_id }, склады);
        }

        // DELETE: api/Склады/5
        [ResponseType(typeof(Склады))]
        public IHttpActionResult DeleteСклады(int id)
        {
            Склады склады = db.Склады.Find(id);
            if (склады == null)
            {
                return NotFound();
            }

            db.Склады.Remove(склады);
            db.SaveChanges();

            return Ok(склады);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool СкладыExists(int id)
        {
            return db.Склады.Count(e => e.склад_id == id) > 0;
        }
    }
}