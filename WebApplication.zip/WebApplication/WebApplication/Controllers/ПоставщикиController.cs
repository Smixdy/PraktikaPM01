﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApplication.Entities;

namespace WebApplication.Controllers
{
    public class ПоставщикиController : ApiController
    {
        private СкладскойУчетEntities db = new СкладскойУчетEntities();

        // GET: api/Поставщики
        public IQueryable<Поставщики> GetПоставщики()
        {
            return db.Поставщики;
        }

        // GET: api/Поставщики/5
        [ResponseType(typeof(Поставщики))]
        public IHttpActionResult GetПоставщики(int id)
        {
            Поставщики поставщики = db.Поставщики.Find(id);
            if (поставщики == null)
            {
                return NotFound();
            }

            return Ok(поставщики);
        }

        // PUT: api/Поставщики/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutПоставщики(int id, Поставщики поставщики)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != поставщики.поставщик_id)
            {
                return BadRequest();
            }

            db.Entry(поставщики).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ПоставщикиExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Поставщики
        [ResponseType(typeof(Поставщики))]
        public IHttpActionResult PostПоставщики(Поставщики поставщики)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Поставщики.Add(поставщики);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = поставщики.поставщик_id }, поставщики);
        }

        // DELETE: api/Поставщики/5
        [ResponseType(typeof(Поставщики))]
        public IHttpActionResult DeleteПоставщики(int id)
        {
            Поставщики поставщики = db.Поставщики.Find(id);
            if (поставщики == null)
            {
                return NotFound();
            }

            db.Поставщики.Remove(поставщики);
            db.SaveChanges();

            return Ok(поставщики);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ПоставщикиExists(int id)
        {
            return db.Поставщики.Count(e => e.поставщик_id == id) > 0;
        }
    }
}