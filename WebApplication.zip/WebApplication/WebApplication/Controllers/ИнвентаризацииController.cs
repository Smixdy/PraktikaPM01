﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApplication.Entities;

namespace WebApplication.Controllers
{
    public class ИнвентаризацииController : ApiController
    {
        private СкладскойУчетEntities db = new СкладскойУчетEntities();

        // GET: api/Инвентаризации
        public IQueryable<Инвентаризации> GetИнвентаризации()
        {
            return db.Инвентаризации;
        }

        // GET: api/Инвентаризации/5
        [ResponseType(typeof(Инвентаризации))]
        public IHttpActionResult GetИнвентаризации(int id)
        {
            Инвентаризации инвентаризации = db.Инвентаризации.Find(id);
            if (инвентаризации == null)
            {
                return NotFound();
            }

            return Ok(инвентаризации);
        }

        // PUT: api/Инвентаризации/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutИнвентаризации(int id, Инвентаризации инвентаризации)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != инвентаризации.инвентаризация_id)
            {
                return BadRequest();
            }

            db.Entry(инвентаризации).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ИнвентаризацииExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Инвентаризации
        [ResponseType(typeof(Инвентаризации))]
        public IHttpActionResult PostИнвентаризации(Инвентаризации инвентаризации)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Инвентаризации.Add(инвентаризации);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = инвентаризации.инвентаризация_id }, инвентаризации);
        }

        // DELETE: api/Инвентаризации/5
        [ResponseType(typeof(Инвентаризации))]
        public IHttpActionResult DeleteИнвентаризации(int id)
        {
            Инвентаризации инвентаризации = db.Инвентаризации.Find(id);
            if (инвентаризации == null)
            {
                return NotFound();
            }

            db.Инвентаризации.Remove(инвентаризации);
            db.SaveChanges();

            return Ok(инвентаризации);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ИнвентаризацииExists(int id)
        {
            return db.Инвентаризации.Count(e => e.инвентаризация_id == id) > 0;
        }
    }
}