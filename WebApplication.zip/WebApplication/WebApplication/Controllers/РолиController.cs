﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApplication.Entities;

namespace WebApplication.Controllers
{
    public class РолиController : ApiController
    {
        private СкладскойУчетEntities db = new СкладскойУчетEntities();

        // GET: api/Роли
        public IQueryable<Роли> GetРоли()
        {
            return db.Роли;
        }

        // GET: api/Роли/5
        [ResponseType(typeof(Роли))]
        public IHttpActionResult GetРоли(int id)
        {
            Роли роли = db.Роли.Find(id);
            if (роли == null)
            {
                return NotFound();
            }

            return Ok(роли);
        }

        // PUT: api/Роли/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutРоли(int id, Роли роли)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != роли.роль_id)
            {
                return BadRequest();
            }

            db.Entry(роли).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!РолиExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Роли
        [ResponseType(typeof(Роли))]
        public IHttpActionResult PostРоли(Роли роли)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Роли.Add(роли);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = роли.роль_id }, роли);
        }

        // DELETE: api/Роли/5
        [ResponseType(typeof(Роли))]
        public IHttpActionResult DeleteРоли(int id)
        {
            Роли роли = db.Роли.Find(id);
            if (роли == null)
            {
                return NotFound();
            }

            db.Роли.Remove(роли);
            db.SaveChanges();

            return Ok(роли);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool РолиExists(int id)
        {
            return db.Роли.Count(e => e.роль_id == id) > 0;
        }
    }
}