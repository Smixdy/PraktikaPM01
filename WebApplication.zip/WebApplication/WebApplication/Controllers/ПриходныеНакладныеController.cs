﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApplication.Entities;

namespace WebApplication.Controllers
{
    public class ПриходныеНакладныеController : ApiController
    {
        private СкладскойУчетEntities db = new СкладскойУчетEntities();

        // GET: api/ПриходныеНакладные
        public IQueryable<ПриходныеНакладные> GetПриходныеНакладные()
        {
            return db.ПриходныеНакладные;
        }

        // GET: api/ПриходныеНакладные/5
        [ResponseType(typeof(ПриходныеНакладные))]
        public IHttpActionResult GetПриходныеНакладные(int id)
        {
            ПриходныеНакладные приходныеНакладные = db.ПриходныеНакладные.Find(id);
            if (приходныеНакладные == null)
            {
                return NotFound();
            }

            return Ok(приходныеНакладные);
        }

        // PUT: api/ПриходныеНакладные/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutПриходныеНакладные(int id, ПриходныеНакладные приходныеНакладные)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != приходныеНакладные.накладная_id)
            {
                return BadRequest();
            }

            db.Entry(приходныеНакладные).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ПриходныеНакладныеExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/ПриходныеНакладные
        [ResponseType(typeof(ПриходныеНакладные))]
        public IHttpActionResult PostПриходныеНакладные(ПриходныеНакладные приходныеНакладные)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.ПриходныеНакладные.Add(приходныеНакладные);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = приходныеНакладные.накладная_id }, приходныеНакладные);
        }

        // DELETE: api/ПриходныеНакладные/5
        [ResponseType(typeof(ПриходныеНакладные))]
        public IHttpActionResult DeleteПриходныеНакладные(int id)
        {
            ПриходныеНакладные приходныеНакладные = db.ПриходныеНакладные.Find(id);
            if (приходныеНакладные == null)
            {
                return NotFound();
            }

            db.ПриходныеНакладные.Remove(приходныеНакладные);
            db.SaveChanges();

            return Ok(приходныеНакладные);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ПриходныеНакладныеExists(int id)
        {
            return db.ПриходныеНакладные.Count(e => e.накладная_id == id) > 0;
        }
    }
}