﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApplication.Entities;

namespace WebApplication.Controllers
{
    public class СодержимоеРасходнойНакладнойController : ApiController
    {
        private СкладскойУчетEntities db = new СкладскойУчетEntities();

        // GET: api/СодержимоеРасходнойНакладной
        public IQueryable<СодержимоеРасходнойНакладной> GetСодержимоеРасходнойНакладной()
        {
            return db.СодержимоеРасходнойНакладной;
        }

        // GET: api/СодержимоеРасходнойНакладной/5
        [ResponseType(typeof(СодержимоеРасходнойНакладной))]
        public IHttpActionResult GetСодержимоеРасходнойНакладной(int id)
        {
            СодержимоеРасходнойНакладной содержимоеРасходнойНакладной = db.СодержимоеРасходнойНакладной.Find(id);
            if (содержимоеРасходнойНакладной == null)
            {
                return NotFound();
            }

            return Ok(содержимоеРасходнойНакладной);
        }

        // PUT: api/СодержимоеРасходнойНакладной/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutСодержимоеРасходнойНакладной(int id, СодержимоеРасходнойНакладной содержимоеРасходнойНакладной)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != содержимоеРасходнойНакладной.накладная_id)
            {
                return BadRequest();
            }

            db.Entry(содержимоеРасходнойНакладной).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!СодержимоеРасходнойНакладнойExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/СодержимоеРасходнойНакладной
        [ResponseType(typeof(СодержимоеРасходнойНакладной))]
        public IHttpActionResult PostСодержимоеРасходнойНакладной(СодержимоеРасходнойНакладной содержимоеРасходнойНакладной)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.СодержимоеРасходнойНакладной.Add(содержимоеРасходнойНакладной);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (СодержимоеРасходнойНакладнойExists(содержимоеРасходнойНакладной.накладная_id))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = содержимоеРасходнойНакладной.накладная_id }, содержимоеРасходнойНакладной);
        }

        // DELETE: api/СодержимоеРасходнойНакладной/5
        [ResponseType(typeof(СодержимоеРасходнойНакладной))]
        public IHttpActionResult DeleteСодержимоеРасходнойНакладной(int id)
        {
            СодержимоеРасходнойНакладной содержимоеРасходнойНакладной = db.СодержимоеРасходнойНакладной.Find(id);
            if (содержимоеРасходнойНакладной == null)
            {
                return NotFound();
            }

            db.СодержимоеРасходнойНакладной.Remove(содержимоеРасходнойНакладной);
            db.SaveChanges();

            return Ok(содержимоеРасходнойНакладной);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool СодержимоеРасходнойНакладнойExists(int id)
        {
            return db.СодержимоеРасходнойНакладной.Count(e => e.накладная_id == id) > 0;
        }
    }
}