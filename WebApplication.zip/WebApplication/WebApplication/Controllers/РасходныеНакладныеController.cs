﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApplication.Entities;

namespace WebApplication.Controllers
{
    public class РасходныеНакладныеController : ApiController
    {
        private СкладскойУчетEntities db = new СкладскойУчетEntities();

        // GET: api/РасходныеНакладные
        public IQueryable<РасходныеНакладные> GetРасходныеНакладные()
        {
            return db.РасходныеНакладные;
        }

        // GET: api/РасходныеНакладные/5
        [ResponseType(typeof(РасходныеНакладные))]
        public IHttpActionResult GetРасходныеНакладные(int id)
        {
            РасходныеНакладные расходныеНакладные = db.РасходныеНакладные.Find(id);
            if (расходныеНакладные == null)
            {
                return NotFound();
            }

            return Ok(расходныеНакладные);
        }

        // PUT: api/РасходныеНакладные/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutРасходныеНакладные(int id, РасходныеНакладные расходныеНакладные)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != расходныеНакладные.накладная_id)
            {
                return BadRequest();
            }

            db.Entry(расходныеНакладные).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!РасходныеНакладныеExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/РасходныеНакладные
        [ResponseType(typeof(РасходныеНакладные))]
        public IHttpActionResult PostРасходныеНакладные(РасходныеНакладные расходныеНакладные)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.РасходныеНакладные.Add(расходныеНакладные);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = расходныеНакладные.накладная_id }, расходныеНакладные);
        }

        // DELETE: api/РасходныеНакладные/5
        [ResponseType(typeof(РасходныеНакладные))]
        public IHttpActionResult DeleteРасходныеНакладные(int id)
        {
            РасходныеНакладные расходныеНакладные = db.РасходныеНакладные.Find(id);
            if (расходныеНакладные == null)
            {
                return NotFound();
            }

            db.РасходныеНакладные.Remove(расходныеНакладные);
            db.SaveChanges();

            return Ok(расходныеНакладные);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool РасходныеНакладныеExists(int id)
        {
            return db.РасходныеНакладные.Count(e => e.накладная_id == id) > 0;
        }
    }
}