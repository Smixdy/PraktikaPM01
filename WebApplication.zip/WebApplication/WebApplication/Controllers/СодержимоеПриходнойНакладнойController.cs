﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApplication.Entities;

namespace WebApplication.Controllers
{
    public class СодержимоеПриходнойНакладнойController : ApiController
    {
        private СкладскойУчетEntities db = new СкладскойУчетEntities();

        // GET: api/СодержимоеПриходнойНакладной
        public IQueryable<СодержимоеПриходнойНакладной> GetСодержимоеПриходнойНакладной()
        {
            return db.СодержимоеПриходнойНакладной;
        }

        // GET: api/СодержимоеПриходнойНакладной/5
        [ResponseType(typeof(СодержимоеПриходнойНакладной))]
        public IHttpActionResult GetСодержимоеПриходнойНакладной(int id)
        {
            СодержимоеПриходнойНакладной содержимоеПриходнойНакладной = db.СодержимоеПриходнойНакладной.Find(id);
            if (содержимоеПриходнойНакладной == null)
            {
                return NotFound();
            }

            return Ok(содержимоеПриходнойНакладной);
        }

        // PUT: api/СодержимоеПриходнойНакладной/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutСодержимоеПриходнойНакладной(int id, СодержимоеПриходнойНакладной содержимоеПриходнойНакладной)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != содержимоеПриходнойНакладной.накладная_id)
            {
                return BadRequest();
            }

            db.Entry(содержимоеПриходнойНакладной).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!СодержимоеПриходнойНакладнойExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/СодержимоеПриходнойНакладной
        [ResponseType(typeof(СодержимоеПриходнойНакладной))]
        public IHttpActionResult PostСодержимоеПриходнойНакладной(СодержимоеПриходнойНакладной содержимоеПриходнойНакладной)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.СодержимоеПриходнойНакладной.Add(содержимоеПриходнойНакладной);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (СодержимоеПриходнойНакладнойExists(содержимоеПриходнойНакладной.накладная_id))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = содержимоеПриходнойНакладной.накладная_id }, содержимоеПриходнойНакладной);
        }

        // DELETE: api/СодержимоеПриходнойНакладной/5
        [ResponseType(typeof(СодержимоеПриходнойНакладной))]
        public IHttpActionResult DeleteСодержимоеПриходнойНакладной(int id)
        {
            СодержимоеПриходнойНакладной содержимоеПриходнойНакладной = db.СодержимоеПриходнойНакладной.Find(id);
            if (содержимоеПриходнойНакладной == null)
            {
                return NotFound();
            }

            db.СодержимоеПриходнойНакладной.Remove(содержимоеПриходнойНакладной);
            db.SaveChanges();

            return Ok(содержимоеПриходнойНакладной);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool СодержимоеПриходнойНакладнойExists(int id)
        {
            return db.СодержимоеПриходнойНакладной.Count(e => e.накладная_id == id) > 0;
        }
    }
}